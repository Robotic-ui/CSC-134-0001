// CSC 134
// M1T2
// Hello world part 2
// Sebastian Rusbacky
// 8/26/2024
// Simple intro program for printing to the screen practice

/* for the future me note fyi in reality it is unsafe to import all of standard lib bc of naming conflicts. Yes it's much shorter code but it will likey become a problem esp with big projects it pollutes the environment :D */

#include <iostream>
using namespace std;

int main() 
{
  cout << "Greetings my name is Sebastian Rusbacky.\n" << endl;
  cout << "I am enrolled in the Programming and associate of science program\n" << endl;
  cout << "My interests are computer programming and playing games specifically puzzle games, which are my favorite it's very much simillar to programming in a sense\n" << endl;
  cout << "My favorite Vehicle is the Porsche 911 GT3 in Shark Blue" << endl;
}